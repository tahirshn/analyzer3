import re
from pathlib import Path
from typing import Dict, Set

MIGRATION_PATH = Path("src/main/resources/db/migration")

def extract_current_indexes() -> Dict[str, Set[str]]:
    index_map: Dict[str, Set[str]] = {}
    dropped_indexes = set()
    created_indexes = {}

    for file in sorted(MIGRATION_PATH.glob("V*.sql")):
        with open(file, encoding="utf-8") as f:
            content = f.read()

            for match in re.finditer(r"CREATE(?: UNIQUE)? INDEX (\w+) ON (\w+)\s*\(([^)]+)\)", content, re.IGNORECASE):
                index_name, table, columns = match.groups()
                column_list = {col.strip().strip('"') for col in columns.split(",")}
                created_indexes[index_name] = (table.lower(), column_list)

            for match in re.finditer(r"DROP INDEX IF EXISTS (\w+)", content, re.IGNORECASE):
                index_name = match.group(1)
                dropped_indexes.add(index_name)

    for index_name in dropped_indexes:
        created_indexes.pop(index_name, None)

    for table, columns in created_indexes.values():
        index_map.setdefault(table, set()).update(columns)

    return index_map

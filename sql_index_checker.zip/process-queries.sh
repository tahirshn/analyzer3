#!/bin/bash

set -e
set -o pipefail

FEATURE_BRANCH=$(git rev-parse --abbrev-ref HEAD)
MASTER_BRANCH="master"
PROJECT_DIR="$(git rev-parse --show-toplevel)"
SQL_COLLECTOR="$PROJECT_DIR/sql_collector.py"

MASTER_SQL="$PROJECT_DIR/master_sql.log"
FEATURE_SQL="$PROJECT_DIR/feature_sql.log"

if [[ "$FEATURE_BRANCH" == "$MASTER_BRANCH" ]]; then
  echo "⛔ Bu script feature branch'te çalıştırılmalıdır."
  exit 1
fi

if [[ -n $(git status --porcelain) ]]; then
  echo "⚠️ Lütfen önce tüm değişiklikleri commit veya stash yap."
  exit 1
fi

ORIGINAL_BRANCH="$FEATURE_BRANCH"

collect_sql_log() {
  local branch=$1
  local out_log=$2

  echo ">>> $branch branch'ine geçiliyor..."
  git checkout "$branch"
  ./gradlew clean test --info | grep -i --line-buffered "Hibernate:" > "$out_log"
  echo "✔ SQL log: $out_log"
}

collect_sql_log "$MASTER_BRANCH" "$MASTER_SQL"
collect_sql_log "$ORIGINAL_BRANCH" "$FEATURE_SQL"

python3 "$SQL_COLLECTOR" "$MASTER_SQL" "$FEATURE_SQL"

git checkout "$ORIGINAL_BRANCH"

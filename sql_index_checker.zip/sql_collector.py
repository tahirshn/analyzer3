import sys
import re
from typing import List, Set
from migration_index_parser import extract_current_indexes

master_log, feature_log = sys.argv[1], sys.argv[2]
INDEXES = extract_current_indexes()

def extract_queries(log_file: str) -> Set[str]:
    queries = set()
    with open(log_file, "r") as f:
        for line in f:
            line = line.strip()
            if line.lower().startswith("hibernate:"):
                sql = line[len("hibernate:"):].strip()
                queries.add(sql)
    return queries

def extract_fields(sql: str) -> List[str]:
    conditions = re.findall(r"\bWHERE\s+(.+?)\s*(GROUP BY|ORDER BY|LIMIT|$)", sql, re.IGNORECASE)
    if not conditions:
        return []
    where_clause = conditions[0][0]
    fields = re.findall(r"\b(\w+\.\w+)", where_clause)
    return list(set(fields))

def is_indexed(field: str) -> bool:
    if "." not in field:
        return False
    table, column = field.split(".")
    return column in INDEXES.get(table.lower(), set())

def check_missing_indexes(new_queries: Set[str]):
    for query in new_queries:
        fields = extract_fields(query)
        if not fields:
            continue
        for field in fields:
            if not is_indexed(field):
                print(f"🚨 Eksik index tespiti: {field} → sorgu: {query}")

master_queries = extract_queries(master_log)
feature_queries = extract_queries(feature_log)

new_queries = feature_queries - master_queries

print(f"🧠 Yeni sorgu sayısı: {len(new_queries)}")
check_missing_indexes(new_queries)
